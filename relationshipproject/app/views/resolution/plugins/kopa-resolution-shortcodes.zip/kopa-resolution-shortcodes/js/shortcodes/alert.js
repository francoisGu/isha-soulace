(function() {  
    tinymce.create('tinymce.plugins.alert', {  
        init : function(ed, url) {  
            ed.addButton('alert', {  
                title : 'Add a alert box',  
                image : url+'/icons/alert.png',  
                onclick : function() {  
                    ed.selection.setContent('[alert title="" type="e.g. warning, danger, success, info"]'+ed.selection.getContent()+'[/alert]');
                }  
            });  
        },  
        createControl : function(n, cm) {  
            return null;  
        }
    });  
    tinymce.PluginManager.add('alert', tinymce.plugins.alert);  
})();

