===Kopa Shortcodes===

Contributors: Kopatheme
Tags: shortcodes
License: GPLv2 or later
Since: Zoombi v1.0.0

A plugin to generate shortcodes in the WordPress visual editor.
Note: Specific use in Zoombi Theme

